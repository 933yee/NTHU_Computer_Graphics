char *textFileRead(const char *fn);
int textFileWrite(char *fn, char *s);
